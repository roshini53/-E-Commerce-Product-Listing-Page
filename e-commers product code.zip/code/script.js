const products = [
  { name: "Wireless Headphones", price: 1999, image: "image/1.jpg" },
  { name: "Smart Watch", price: 2499, image: "image/2.jpg" },
  { name: "Bluetooth Speaker", price: 1299, image: "image/3.jpg" },
  { name: "Fitness Band", price: 899, image: "image/4.jpg" },
  { name: "Portable Charger", price: 1199, image: "image/5.jpg" },
  { name: "USB Cable Pack", price: 499, image: "image/6.jpg" }
];

const productList = document.getElementById("productList");
const searchInput = document.getElementById("searchInput");

const detailSection = document.getElementById("productDetail");
const detailTitle = document.getElementById("detailTitle");
const detailImage = document.getElementById("detailImage");
const detailPrice = document.getElementById("detailPrice");
const addToCartBtn = document.getElementById("addToCartBtn");

const cartItems = document.getElementById("cartItems");
const cartTotal = document.getElementById("cartTotal");

let selectedProduct = null;
let cart = [];

// Display all products
function displaySidebarProducts(filteredProducts) {
  productList.innerHTML = "";
  filteredProducts.forEach((product, index) => {
    const item = document.createElement("div");
    item.classList.add("product-item");

    item.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <div class="product-item-info">
        <h3>${product.name}</h3>
        <p>₹${product.price}</p>
      </div>
      <button onclick="showProductDetail(${index})">View</button>
    `;

    productList.appendChild(item);
  });
}

// Search functionality
searchInput.addEventListener("input", () => {
  const query = searchInput.value.toLowerCase();
  const filtered = products.filter(p => p.name.toLowerCase().includes(query));
  displaySidebarProducts(filtered);
});

// Show product detail
window.showProductDetail = function(index) {
  selectedProduct = products[index];
  detailTitle.textContent = selectedProduct.name;
  detailImage.src = selectedProduct.image;
  detailPrice.textContent = `Price: ₹${selectedProduct.price}`;
  detailSection.classList.remove("hidden");
  window.scrollTo({ top: detailSection.offsetTop - 80, behavior: "smooth" });
};

// Add to cart
addToCartBtn.addEventListener("click", () => {
  if (selectedProduct) {
    cart.push(selectedProduct);
    updateCart();
    alert(`${selectedProduct.name} added to cart!`);
  }
});

// Update cart display
function updateCart() {
  cartItems.innerHTML = "";
  let total = 0;
  cart.forEach((item, index) => {
    total += item.price;
    const li = document.createElement("li");
    li.innerHTML = `${item.name} - ₹${item.price} <button onclick="removeFromCart(${index})">Remove</button>`;
    cartItems.appendChild(li);
  });
  cartTotal.textContent = `Total: ₹${total}`;
}

// Remove from cart
window.removeFromCart = function(index) {
  cart.splice(index, 1);
  updateCart();
}

// Load products on start
displaySidebarProducts(products);
